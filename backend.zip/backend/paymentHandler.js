// require("colors")
// require("dotenv").config({
//     path:'./.env'
// })
// const express = require("express")
// const { PayData } = require("./payu.config")

// const app = express()
// const port = process.env.PORT || 4500
// const cors = require("cors")

// const mysql = require('mysql2');

// const bodyParser = require('body-parser');

// // middleware

// app.use(express.json())
// app.use(express.urlencoded({extended:false}))
// app.use(cors())
// app.use(bodyParser.json());



// // Connect to MySQL
// const db = mysql.createConnection({
//   host: 'localhost',
//   user: 'root',
//   password: '', // default XAMPP password is empty
//   database: 'business_form'
// });

// // Connect to DB
// db.connect(err => {
//   if (err) {
//     console.error('DB connection failed:', err);
//   } else {
//     console.log('MySQL connected!');
//   }
// });


// // app.post("/get-payment",async(req,res)=>{
// //             try {
// //                 const txn_id='PAYU_MONEY_'+Math.floor(Math.random()*8888888)
// //                     const { amount,product,firstname,email,mobile } =req.body

// //                 //    let amount=233
// //                 //    let product = JSON.stringify({
// //                 //     name:'T-shirt',
// //                 //     price:233
// //                 //    })
// //                 //    let firstname='Krishna'
// //                 //    let email="harish@gmail.com"
// //                 //    let mobile = 2345678912

// //                     let udf1 = ''
// //                     let udf2 = ''
// //                     let udf3 = ''
// //                     let udf4 = ''
// //                     let udf5 = ''

// //                     const hashString = `${PayData.payu_key}|${txn_id}|${amount}|${JSON.stringify(product)}|${firstname}|${email}|${udf1}|${udf2}|${udf3}|${udf4}|${udf5}||||||${PayData.payu_salt}`;
// //                     // console.log(hashString);
                    
     
// //     // Calculate the hash
// //     const hash = crypto.createHash('sha512').update(hashString).digest('hex');

// //                const data=    await PayData.payuClient.paymentInitiate({
           
                    
// //                             isAmountFilledByCustomer:false,
// //                                 txnid:txn_id,
// //                                 amount:amount,
// //                                 currency: 'INR',
// //                                 productinfo:JSON.stringify(product),
// //                                 firstname:firstname,
// //                                 email:email,
// //                                 phone:mobile,
// //                                 surl:`http://localhost:${port}/verify/${txn_id}`,
// //                                 furl:`http://localhost:${port}/verify/${txn_id}`,
// //                                 hash
                    

// //                     }) 
// //                     res.send(data)
// //             } catch (error) {
// //                         res.status(400).send({
// //                             msg:error.message,
// //                             stack:error.stack
// //                         })
// //             }
// // })

// const crypto = require("crypto");

// app.post("/get-payment", async (req, res) => {
//   try {
//     const txn_id = 'PAYU_MONEY_' + Math.floor(Math.random() * 8888888);
//     const { amount, product, firstname, email, mobile } = req.body;

//     let udf1 = '', udf2 = '', udf3 = '', udf4 = '', udf5 = '';

//     const hashString = `${PayData.payu_key}|${txn_id}|${amount}|${JSON.stringify(product)}|${firstname}|${email}|${udf1}|${udf2}|${udf3}|${udf4}|${udf5}||||||${PayData.payu_salt}`;
//     const hash = crypto.createHash('sha512').update(hashString).digest('hex');

//     // 👉 Save to MySQL BEFORE initiating payment
//     const sql = `
//       INSERT INTO payments (name, email, mobile, payment_method, txnid, amt)
//       VALUES (?, ?, ?, ?, ?, ?)
//     `;
//     const values = [firstname, email, mobile, 'PayU', txn_id, amount];

//     db.query(sql, values, (err, result) => {
//       if (err) {
//         console.error("MySQL Insert Error:", err.message);
//         return res.status(500).json({ msg: "DB Error", error: err.message });
//       }

//       console.log("Payment initiated and saved to DB");

//       // 👉 Initiate PayU payment
//       PayData.payuClient.paymentInitiate({
//         isAmountFilledByCustomer: false,
//         txnid: txn_id,
//         amount,
//         currency: 'INR',
//         productinfo: JSON.stringify(product),
//         firstname,
//         email,
//         phone: mobile,
//         surl: `http://localhost:${port}/verify/${txn_id}`,
//         furl: `http://localhost:${port}/verify/${txn_id}`,
//         hash,
//       }).then(data => {
//         res.send(data);
//       }).catch(error => {
//         res.status(400).send({
//           msg: error.message,
//           stack: error.stack
//         });
//       });
//     });

//   } catch (error) {
//     res.status(400).send({
//       msg: error.message,
//       stack: error.stack
//     });
//   }
// });



// app.post("/verify/:txnid",async(req,res)=>{
//     // res.send("Done")


//         const verified_Data = await PayData.payuClient.verifyPayment(req.params.txnid);
//         const data = verified_Data.transaction_details[req.params.txnid]
         
      
//         const created_at = encodeURIComponent(new Date(data.addedon).toLocaleString());
// const error = encodeURIComponent(data.error_Message || 'none');


// res.redirect(`http://localhost:5173/payment?status=${data.status}&txnid=${data.txnid}&amt=${data.amt}&mode=${data.mode}&error=${error}&created_at=${created_at}`);

       
// })


// app.post('/save-payment', (req, res) => {
//   const { name, email, mobile, amt } = req.body;

//   const sql = `
//     INSERT INTO payments (name, email, mobile, amount, payment_method)
//     VALUES (?, ?, ?, ?, 'Online')
//   `;

//   db.query(sql, [name, email, mobile, amt], (err, result) => {
//     if (err) {
//       console.error('Insert error:', err);
//       return res.status(500).json({ msg: 'Database insert failed' });
//     }
//     res.json({ msg: 'Payment data saved', id: result.insertId });
//   });
// });


// // run the application
// app.listen(port,()=>{
//     console.log(`the app is listen at http://localhost:${port}`.bgCyan.white);
    
// })

//res.redirect(`http://localhost:5173/payment/${data.status}/${data.txnid}/${data.amt}/${data.mode}/${error}/${created_at}`);

//        res.redirect(`http://localhost:5173/payment/${query}/${data.status}/${data.txnid}`)


 // res.send({
        //     status:data.status,
        //     amt:data.amt,
        //     txnid:data.txnid,
        //     method:data.mode,
        //     error:data.error_Message,
        //     created_at:new Date(data.addedon).toLocaleString()
        // })
// PAYU_MONEY_4996538



require("colors");
require("dotenv").config({ path: './.env' });

const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const { PayData } = require("./payu.config");

const app = express();
const port = 4000; // hardcoded to match frontend
const mysql = require('mysql2');
const bodyParser = require('body-parser');
// require('dotenv').config();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());
app.use(bodyParser.json());

// DB Connect
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'business_form',
});

db.connect(err => {
  if (err) return console.error('DB connection failed:', err);
  console.log('MySQL connected!');
});

// Get Payment Route
app.post("/get-payment", async (req, res) => {
  try {
    const txn_id = 'PAYU_MONEY_' + Math.floor(Math.random() * 8888888);
    const { amount, product, firstname, email, mobile, company, message } = req.body;

    const hashString = `${PayData.payu_key}|${txn_id}|${amount}|${JSON.stringify(product)}|${firstname}|${email}|||||||||||${PayData.payu_salt}`;
    const hash = crypto.createHash('sha512').update(hashString).digest('hex');

    // Save to MySQL
    const sql = `
      INSERT INTO payments (name, email, mobile, company, message, payment_method, txnid, amt, payment_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [firstname, email, mobile, company, message, 'PayU', txn_id, amount, 'Pending'];

    db.query(sql, values, async (err, result) => {
      if (err) return res.status(500).json({ msg: "DB Error", error: err.message });

      console.log("Payment initiated and saved to DB");

      try {
        const response = await PayData.payuClient.paymentInitiate({
          isAmountFilledByCustomer: false,
          txnid: txn_id,
          amount,
          currency: 'INR',
          productinfo: JSON.stringify(product),
          firstname,
          email,
          phone: mobile,
          surl: `http://localhost:${port}/verify/${txn_id}`,
          furl: `http://localhost:${port}/verify/${txn_id}`,
          hash,
        });

        if (!response) return res.status(500).json({ msg: "No response from payment gateway" });
        res.send(response);
      } catch (error) {
        res.status(400).json({ msg: error.message, stack: error.stack });
      }
    });
  } catch (error) {
    res.status(400).json({ msg: error.message, stack: error.stack });
  }
});

// ✅ Get all payments
app.get("/all-payments", (req, res) => {
  db.query("SELECT * FROM payments ORDER BY id DESC", (err, results) => {
    if (err) return res.status(500).json({ msg: "DB Error", error: err.message });
    res.status(200).json(results);
  });
});

const nodemailer = require("nodemailer");

app.post("/verify/:txnid", async (req, res) => {
  try {
    const verified_Data = await PayData.payuClient.verifyPayment(req.params.txnid);
    const data = verified_Data.transaction_details[req.params.txnid];

    // ✅ Update payment_status in DB
    const status = data.status === 'success' ? 'Success' : 'Failed';

    db.query(`UPDATE payments SET payment_status = ? WHERE txnid = ?`, [status, req.params.txnid], (err) => {
      if (err) {
        console.error('Status update failed:', err.message);
      } else {
        console.log(`Payment status updated to '${status}' for txnid: ${req.params.txnid}`);

        // ✅ Fetch email and name from DB
        db.query(`SELECT email, name FROM payments WHERE txnid = ?`, [req.params.txnid], (emailErr, result) => {
          if (emailErr || result.length === 0) {
            return console.error("Email fetch failed:", emailErr?.message || "No result");
          }

          const recipientEmail = result[0].email;
          const userName = result[0].name; // Captured user name

          const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
              user: process.env.EMAIL_ID,
              pass: process.env.EMAIL_PASSWORD,
            },
          });

          const mailOptions = {
            from: `"Payment Gateway" <${process.env.EMAIL_ID}>`,
            to: recipientEmail,
            subject: `Payment ${status} - ₹${data.amt}`,
            html: `
              <div style="font-family: 'Arial', sans-serif; background-color: #f4f4f9; color: #333; padding: 20px; border-radius: 10px;">
                <!-- Logo Section -->
                <div style="text-align: center; padding-bottom: 20px;">
                  <img src="https://www.mcrindia.in/img/mcrlogo.JPG" alt="MCRT Logo" style="max-width: 200px; border-radius: 8px;" />
                </div>

                <!-- Email Content -->
                <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
                  <h2 style="text-align: center; color: #4a90e2; font-size: 26px;">Thank You for Registering for MCRT Webinar</h2>
                  <p style="font-size: 18px; line-height: 1.6;">Hi <strong>${userName}</strong>,</p>
                  <p style="font-size: 16px; line-height: 1.6;">Thank you for registering for the MCRT Webinar! Please save this email for future reference and details about the upcoming webcast.</p>
                  <p style="font-size: 16px; line-height: 1.6;"><strong>LIVE WEBCAST DATE:</strong> May 25, 2025</p>
                  <p style="font-size: 16px; line-height: 1.6;"><strong>LIVE WEBCAST TIME:</strong> 11:00 AM IST</p>
                  <p style="font-size: 16px; line-height: 1.6;">Use the link below to enter the webcast, available up to 15 minutes before the start time.</p>
                  <p style="font-size: 16px; line-height: 1.6; text-align: center;">
                    <a href="https://www.mcrt.com/webcast" target="_blank" style="background-color: #4a90e2; color: #fff; padding: 12px 25px; text-decoration: none; font-size: 16px; border-radius: 30px;">Enter Webcast</a>
                  </p>
                  <p style="font-size: 16px; line-height: 1.6;">For any questions, feel free to reach out to us at: <a href="mailto:enquiry@mcrt.com">enquiry@mcrt.com</a></p>
                  <p style="font-size: 16px; line-height: 1.6;">We look forward to having you join the event!</p>

                  <hr style="border-top: 1px solid #ccc; margin: 20px 0;" />

                  <h3 style="text-align: center; color: #4a90e2; font-size: 22px;">Payment Details</h3>
                  <div style="font-size: 16px; line-height: 1.6;">
                    <p><strong>Payment Status:</strong> <span style="color: ${status === 'Success' ? 'green' : 'red'};">${status}</span></p>
                    <p><strong>Amount Paid:</strong> ₹${data.amt}</p>
                    <p><strong>Payment Method:</strong> ${data.mode}</p>
                    <p><strong>Payment Date & Time:</strong> ${new Date(data.addedon).toLocaleString()}</p>
                    <p><strong>Transaction ID:</strong> ${data.txnid}</p>
                    ${status !== 'Success' ? `<p><strong>Error Message:</strong> ${data.error_Message || 'N/A'}</p>` : ''}
                  </div>

                  <hr style="border-top: 1px solid #ccc; margin: 20px 0;" />
                  <p style="font-size: 14px; color: #777; text-align: center;">For more details, visit our website: <a href="https://www.mcrt.com" target="_blank" style="color: #4a90e2;">www.mcrt.com</a></p>
                </div>

                <footer style="text-align: center; margin-top: 20px;">
                  <p style="font-size: 14px; color: #777;">© 2025 MCRT. All rights reserved.</p>
                </footer>
              </div>
            `
          };

          transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
              console.log("Email failed:", error);
            } else {
              console.log("Email sent: " + info.response);
            }
          });
        });
      }
    });

    
    const created_at = encodeURIComponent(new Date(data.addedon).toLocaleString());
    const error = encodeURIComponent(data.error_Message || 'none');

    res.redirect(`http://localhost:8080/payment?status=${data.status}&txnid=${data.txnid}&amt=${data.amt}&mode=${data.mode}&error=${error}&created_at=${created_at}`);
  } catch (error) {
    res.status(400).json({ msg: error.message, stack: error.stack });
  }
});


// app.post("/verify/:txnid", async (req, res) => {
//   try {
//     const verified_Data = await PayData.payuClient.verifyPayment(req.params.txnid);
//     const data = verified_Data.transaction_details[req.params.txnid];

//     // ✅ Update payment_status in DB
//     const status = data.status === 'success' ? 'Success' : 'Failed';

//     db.query(`UPDATE payments SET payment_status = ? WHERE txnid = ?`, [status, req.params.txnid], (err) => {
//       if (err) {
//         console.error('Status update failed:', err.message);
//       } else {
//         console.log(`Payment status updated to '${status}' for txnid: ${req.params.txnid}`);

//         // ✅ Fetch email and name from DB
//         db.query(`SELECT email, name FROM payments WHERE txnid = ?`, [req.params.txnid], (emailErr, result) => {
//           if (emailErr || result.length === 0) {
//             return console.error("Email fetch failed:", emailErr?.message || "No result");
//           }

//           const recipientEmail = result[0].email;
//           const userName = result[0].name; // Captured user name

//           const transporter = nodemailer.createTransport({
//             service: 'gmail',
//             auth: {
//               user: process.env.EMAIL_ID,
//               pass: process.env.EMAIL_PASSWORD,
//             },
//           });

//           // const mailOptions = {
//           //   from: `"Payment Gateway" <${process.env.EMAIL_ID}>`,
//           //   to: recipientEmail,
//           //   subject: `Payment ${status} - ₹${data.amt}`,
//           //   html: `
//           //     <div style="font-family: 'Arial', sans-serif; background-color: #f4f4f9; color: #333; padding: 20px; border-radius: 10px;">
//           //       <!-- Logo Section -->
//           //       <div style="text-align: center; padding-bottom: 20px;">
//           //         <img src="https://www.mcrindia.in/img/mcrlogo.JPG" alt="MCRT Logo" style="max-width: 200px; border-radius: 8px;" />
//           //       </div>

//           //       <!-- Email Content -->
//           //       <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
//           //         <h2 style="text-align: center; color: #4a90e2; font-size: 26px;">Thank You for Registering for MCRT Webinar</h2>
//           //         <p style="font-size: 18px; line-height: 1.6;">Hi <strong>${userName}</strong>,</p>
//           //         <p style="font-size: 16px; line-height: 1.6;">Thank you for registering for the MCRT Webinar! Please save this email for future reference and details about the upcoming webcast.</p>
//           //         <p style="font-size: 16px; line-height: 1.6;"><strong>LIVE WEBCAST DATE:</strong> May 25, 2025</p>
//           //         <p style="font-size: 16px; line-height: 1.6;"><strong>LIVE WEBCAST TIME:</strong> 11:00 AM IST</p>
//           //         <p style="font-size: 16px; line-height: 1.6;">Use the link below to enter the webcast, available up to 15 minutes before the start time.</p>
//           //         <p style="font-size: 16px; line-height: 1.6; text-align: center;">
//           //           <a href="https://www.mcrt.com/webcast" target="_blank" style="background-color: #4a90e2; color: #fff; padding: 12px 25px; text-decoration: none; font-size: 16px; border-radius: 30px;">Enter Webcast</a>
//           //         </p>
//           //         <p style="font-size: 16px; line-height: 1.6;">For any questions, feel free to reach out to us at: <a href="mailto:enquiry@mcrt.com">enquiry@mcrt.com</a></p>
//           //         <p style="font-size: 16px; line-height: 1.6;">We look forward to having you join the event!</p>

//           //         <hr style="border-top: 1px solid #ccc; margin: 20px 0;" />

//           //         <h3 style="text-align: center; color: #4a90e2; font-size: 22px;">Payment Details</h3>
//           //         <div style="font-size: 16px; line-height: 1.6;">
//           //           <p><strong>Payment Status:</strong> <span style="color: ${status === 'Success' ? 'green' : 'red'};">${status}</span></p>
//           //           <p><strong>Amount Paid:</strong> ₹${data.amt}</p>
//           //           <p><strong>Payment Method:</strong> ${data.mode}</p>
//           //           <p><strong>Payment Date & Time:</strong> ${new Date(data.addedon).toLocaleString()}</p>
//           //           <p><strong>Transaction ID:</strong> ${data.txnid}</p>
//           //           ${status !== 'Success' ? `<p><strong>Error Message:</strong> ${data.error_Message || 'N/A'}</p>` : ''}
//           //         </div>

//           //         <hr style="border-top: 1px solid #ccc; margin: 20px 0;" />
//           //         <p style="font-size: 14px; color: #777; text-align: center;">For more details, visit our website: <a href="https://www.mcrt.com" target="_blank" style="color: #4a90e2;">www.mcrt.com</a></p>
//           //       </div>

//           //       <footer style="text-align: center; margin-top: 20px;">
//           //         <p style="font-size: 14px; color: #777;">© 2025 MCRT. All rights reserved.</p>
//           //       </footer>
//           //     </div>
//           //   `
//           // };
//           const mailOptions = {
//   from: `"Payment Gateway" <${process.env.EMAIL_ID}>`,
//   to: recipientEmail,
//   subject: `Payment ${status} - ₹${data.amt}`,
//   html: `
//     <div style="font-family: 'Arial', sans-serif; background-color: #f4f4f9; color: #333; padding: 20px; border-radius: 10px;">
//       <!-- Logo Section -->
//       <div style="text-align: center; padding-bottom: 20px;">
//         <img src="cid:mcrtlogo" alt="MCRT Logo" style="max-width: 200px; border-radius: 8px;" />
//       </div>

//       <!-- Email Content -->
//       <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);">
//         <h2 style="text-align: center; color: #4a90e2; font-size: 26px;">Thank You for Registering for MCRT Webinar</h2>
//         <p style="font-size: 18px; line-height: 1.6;">Hi <strong>${userName}</strong>,</p>
//         <p style="font-size: 16px; line-height: 1.6;">Thank you for registering for the MCRT Webinar! Please save this email for future reference and details about the upcoming webcast.</p>
//         <p style="font-size: 16px; line-height: 1.6;"><strong>LIVE WEBCAST DATE:</strong> May 25, 2025</p>
//         <p style="font-size: 16px; line-height: 1.6;"><strong>LIVE WEBCAST TIME:</strong> 11:00 AM IST</p>
//         <p style="font-size: 16px; line-height: 1.6;">Use the link below to enter the webcast, available up to 15 minutes before the start time.</p>
//         <p style="font-size: 16px; line-height: 1.6; text-align: center;">
//           <a href="https://www.mcrt.com/webcast" target="_blank" style="background-color: #4a90e2; color: #fff; padding: 12px 25px; text-decoration: none; font-size: 16px; border-radius: 30px;">Enter Webcast</a>
//         </p>
//         <p style="font-size: 16px; line-height: 1.6;">For any questions, feel free to reach out to us at: <a href="mailto:enquiry@mcrt.com">enquiry@mcrt.com</a></p>
//         <p style="font-size: 16px; line-height: 1.6;">We look forward to having you join the event!</p>

//         <hr style="border-top: 1px solid #ccc; margin: 20px 0;" />

//         <h3 style="text-align: center; color: #4a90e2; font-size: 22px;">Payment Details</h3>
//         <div style="font-size: 16px; line-height: 1.6;">
//           <p><strong>Payment Status:</strong> <span style="color: ${status === 'Success' ? 'green' : 'red'};">${status}</span></p>
//           <p><strong>Amount Paid:</strong> ₹${data.amt}</p>
//           <p><strong>Payment Method:</strong> ${data.mode}</p>
//           <p><strong>Payment Date & Time:</strong> ${new Date(data.addedon).toLocaleString()}</p>
//           <p><strong>Transaction ID:</strong> ${data.txnid}</p>
//           ${status !== 'Success' ? `<p><strong>Error Message:</strong> ${data.error_Message || 'N/A'}</p>` : ''}
//         </div>

//         <hr style="border-top: 1px solid #ccc; margin: 20px 0;" />
//         <p style="font-size: 14px; color: #777; text-align: center;">For more details, visit our website: <a href="https://www.mcrt.com" target="_blank" style="color: #4a90e2;">www.mcrt.com</a></p>
//       </div>

//       <footer style="text-align: center; margin-top: 20px;">
//         <p style="font-size: 14px; color: #777;">© 2025 MCRT. All rights reserved.</p>
//       </footer>
//     </div>
//   `,
//   attachments: [
//     {
//       filename: 'logo.png',
//       path: '../assets/Mcrt-logo.jpg', // adjust path if needed
//       cid: 'mcrtlogo' // same as used in the img src="cid:..."
//     }
//   ]
// };

//           transporter.sendMail(mailOptions, (error, info) => {
//             if (error) {
//               console.log("Email failed:", error);
//             } else {
//               console.log("Email sent: " + info.response);
//             }
//           });
//         });
//       }
//     });
//     res.send(data);
//   } catch (error) {
//     console.error('Payment verification failed:', error);
//     res.status(500).json({ msg: 'Verification failed', error: error.message });
//   }
// });

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
