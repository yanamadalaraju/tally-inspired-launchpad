const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 5000;

// MySQL database connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'business_form',
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database.');
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// POST route to handle form submission
app.post('/submit-form', (req, res) => {
  const { name, email, phone, company, message } = req.body;

  if (!name || !email || !phone || !company || !message) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const query = `INSERT INTO demo_requests (name, email, phone, company, message) 
                 VALUES (?, ?, ?, ?, ?)`;

  db.query(query, [name, email, phone, company, message], (err, result) => {
    if (err) {
      console.error('Error inserting data: ', err);
      return res.status(500).json({ error: 'An error occurred while submitting the form.' });
    }
    res.status(200).json({ message: 'Form submitted successfully!' });
  });
});

app.get('/get-requests', (req, res) => {
  const query = 'SELECT * FROM demo_requests ORDER BY id DESC';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching data:', err);
      return res.status(500).json({ error: 'Failed to fetch requests' });
    }
    res.status(200).json(results);
  });
});


// Get request by ID
// Express.js route to fetch demo request by ID
app.get('/get-request/:id', (req, res) => {
  const { id } = req.params;
  const query = 'SELECT * FROM demo_requests WHERE id = ?';

  db.query(query, [id], (err, results) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ message: 'Error fetching the demo request', error: err });
    }
    if (results.length === 0) {
      return res.status(404).json({ message: 'Request not found' });
    }
    res.status(200).json(results[0]);
  });
});

// Express.js route to update demo request
app.put('/update-request/:id', (req, res) => {
  const { id } = req.params;
  const { name, email, phone, company, message } = req.body;

  // Validate the data
  if (!name || !email) {
    return res.status(400).json({ message: 'Name and email are required fields.' });
  }

  const query = 'UPDATE demo_requests SET name = ?, email = ?, phone = ?, company = ?, message = ? WHERE id = ?';
  db.query(query, [name, email, phone, company, message, id], (err, results) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).json({ message: 'Error updating the demo request', error: err });
    }
    if (results.affectedRows === 0) {
      return res.status(404).json({ message: 'Request not found' });
    }
    res.status(200).json({ success: true, message: 'Request updated successfully' });
  });
});

app.delete('/delete-request/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM demo_requests WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error deleting request:', err);
      return res.status(500).json({ error: 'Failed to delete request' });
    }
    res.status(200).json({ message: 'Request deleted successfully' });
  });
});


app.post("/get-payment", async (req, res) => {
  try {
    const txn_id = 'PAYU_MONEY_' + Math.floor(Math.random() * 8888888);
    const { amount, product, firstname, email, mobile } = req.body;

    const hashString = `${PayData.payu_key}|${txn_id}|${amount}|${JSON.stringify(product)}|${firstname}|${email}|||||||||||${PayData.payu_salt}`;
    const hash = crypto.createHash('sha512').update(hashString).digest('hex');

    // Save to MySQL
    const sql = `
      INSERT INTO payments (name, email, mobile, payment_method, txnid, amt, payment_status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    const values = [firstname, email, mobile, 'PayU', txn_id, amount, 'Pending'];

    db.query(sql, values, async (err, result) => {
      if (err) return res.status(500).json({ msg: "DB Error", error: err.message });

      console.log("Payment initiated and saved to DB");

      try {
        const response = await PayData.payuClient.paymentInitiate({
          isAmountFilledByCustomer: false,
          txnid: txn_id,
          amount,
          currency: 'INR',
          productinfo: JSON.stringify(product),
          firstname,
          email,
          phone: mobile,
          surl: `http://localhost:${port}/verify/${txn_id}`,
          furl: `http://localhost:${port}/verify/${txn_id}`,
          hash,
        });

        if (!response) return res.status(500).json({ msg: "No response from payment gateway" });
        res.send(response);
      } catch (error) {
        res.status(400).json({ msg: error.message, stack: error.stack });
      }
    });
  } catch (error) {
    res.status(400).json({ msg: error.message, stack: error.stack });
  }
});


// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
